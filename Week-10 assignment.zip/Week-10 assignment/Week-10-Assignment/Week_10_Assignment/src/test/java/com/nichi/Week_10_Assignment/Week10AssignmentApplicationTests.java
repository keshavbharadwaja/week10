package com.nichi.Week_10_Assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week10AssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
