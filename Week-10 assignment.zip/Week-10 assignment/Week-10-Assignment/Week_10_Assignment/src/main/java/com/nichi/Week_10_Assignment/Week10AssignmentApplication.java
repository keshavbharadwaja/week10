package com.nichi.Week_10_Assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week10AssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week10AssignmentApplication.class, args);
	}

}
